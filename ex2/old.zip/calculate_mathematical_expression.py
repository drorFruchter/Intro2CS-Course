# def adjust_type(score: float):
#     if score % 1 == 0:
#         return int(score)
#     return float(score)

def calculate_mathematical_expression(num1, num2 , operation):
    if operation == '+':
        return num1 + num2
        # return adjust_type(num1 + num2)
    elif operation == '-':
        return num1 - num2
    # return adjust_type(num1 - num2)
    elif operation == '*':
        return num1 * num2
    # return adjust_type(num1 * num2)
    elif operation == ':' and num2 != 0:
        return num1 / num2
    return None

def calculate_from_string(expression):
    num1, operation, num2 = expression.split()
    return calculate_mathematical_expression(float(num1), float(num2), operation)
