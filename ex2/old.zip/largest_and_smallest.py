def largest_and_smallest(num1, num2, num3):
    if num1 >= num2 and num1 >= num3:
        largest = num1
        if num2 >= num3:
            smallest = num3
        else:
            smallest = num2
    elif num2 >= num1 and num2 >= num3:
        largest = num2
        if num1 >= num3:
            smallest = num3
        else:
            smallest = num1
    else:
        largest = num3
        if num1 >= num2:
            smallest = num2
        else:
            smallest = num1
    return largest, smallest


def check_largest_and_smallest():
    if largest_and_smallest(17, 1, 6) != (17, 1):
        return False
    elif largest_and_smallest(1, 17, 6) != (17, 1):
        return False
    elif largest_and_smallest(1, 1, 2) != (2, 1):
        return False
    elif largest_and_smallest(1.5, 1, 2.6) != (2.6, 1):
        # Checks if the function accepts both ints and floats
        return False
    elif largest_and_smallest(0, 0, 0) != (0, 0):
        # Checks if the function accepts all of the same value
        return False
    return True