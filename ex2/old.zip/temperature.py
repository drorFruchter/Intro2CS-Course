def is_vormir_safe(extreme_temp, temp1, temp2, temp3):
    if temp1 > extreme_temp and temp2 > extreme_temp:
        return True
    elif temp1 > extreme_temp and temp3 > extreme_temp:
        return True
    elif temp2 > extreme_temp and temp3 > extreme_temp:
        return True
    return False
