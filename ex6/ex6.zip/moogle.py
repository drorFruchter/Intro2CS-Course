import urllib.parse
# full_url = urllib.parse.urljoin(base_url, relative_url)


def main():
    pass


if __name__ == "__main__":
    main()